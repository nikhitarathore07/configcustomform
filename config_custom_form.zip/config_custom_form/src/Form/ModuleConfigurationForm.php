<?php

namespace Drupal\config_custom_form\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Defines a form that configures forms module settings.
 */
class ModuleConfigurationForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'config_custom_form_admin_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'config_custom_form.settings',
    ];
  }

 /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $config = $this->config('config_custom_form.settings');
    $form['assets_type'] = array(
      '#title' => t('Asset Type'),
      '#type' => 'select',
      '#options' => [
        'Custom' => 'Custom',
        'Default' => 'Default',
      ],
      '#required' => TRUE,
      '#default_value' => $config->get('assets_type'),
    );
    $form['assets_css'] = array(
      '#title' => t('Css Assets'),
      '#type' => 'textarea',
      '#states' => [
            'visible' => [
              ':input[name="assets_type"]' => ['value' => 'Custom'],
            ],
       ],
       '#default_value' => $config->get('assets_css'),
    );
    $form['assets_js'] = array(
      '#title' => t('JS Assets'),
      '#type' => 'textarea',
      '#states' => [
            'visible' => [
              ':input[name="assets_type"]' => ['value' => 'Custom'],
            ],
       ],
       '#default_value' => $config->get('assets_js'),
    );
    return parent::buildForm($form, $form_state);
  }

 /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('config_custom_form.settings')
      ->set('assets_css', $form_state->getValue('assets_css'))
      ->save();
   $this->config('config_custom_form.settings')
      ->set('assets_js', $form_state->getValue('assets_js'))
      ->save();
      $this->config('config_custom_form.settings')
      ->set('assets_type', $form_state->getValue('assets'))
      ->save();  
    parent::submitForm($form, $form_state);
  } 

}